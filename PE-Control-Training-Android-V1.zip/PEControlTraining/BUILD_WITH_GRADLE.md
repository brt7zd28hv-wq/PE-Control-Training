The Android Gradle wrapper JAR is not bundled in this generated project because this environment cannot download external build binaries.
Open the project in Android Studio, let it generate/sync the Gradle wrapper, then build the debug APK.
Alternatively upload the project to a CI service and use .github/workflows/build-apk.yml.
