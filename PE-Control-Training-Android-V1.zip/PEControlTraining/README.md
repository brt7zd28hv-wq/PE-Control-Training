# PE Control Training — Android / Fire TV V1

A TV-first Android prototype for private stamina/control training.

## V1
- Adjustable metronome BPM
- 10 progressive levels
- Session timer
- High-intensity challenge toggle
- D-pad/remote navigation for Fire TV
- Touch controls for Android phones/tablets
- Persistent BPM/level/settings
- Placeholder source/category configuration for the later permitted-video feed

## Build
Open the project in Android Studio and run:

    ./gradlew assembleDebug

Android's documentation says the resulting debug APK is installable on a device.

## Important
The video-source feature is intentionally designed around permitted/public-domain or appropriately licensed material. It should not bypass DRM, access controls, paywalls, or copyright restrictions.

This is a wellness/training tool, not a guaranteed medical treatment. Avoid painful or injurious training and seek professional medical advice for persistent or distressing symptoms.
