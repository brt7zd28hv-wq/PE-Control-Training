# PE Control TV v2
Fire TV Android app with Videos as the default section, configurable online sources, admin settings and PE Control training.
Video playback opens configured online sources in the Fire TV WebView. No protected-stream extraction or DRM bypass is implemented.
