package com.example.pecontroltraining;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREFS="pecontrol";
    private LinearLayout root;
    private WebView web;
    private Handler handler=new Handler(Looper.getMainLooper());
    private boolean running=false, high=false;
    private int bpm=80, level=1;
    private long seconds=0;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        load(); showVideos();
    }
    private void load(){
        SharedPreferences p=getSharedPreferences(PREFS,0);
        bpm=p.getInt("bpm",80); level=p.getInt("level",1); high=p.getBoolean("high",false);
    }
    private void save(){
        getSharedPreferences(PREFS,0).edit().putInt("bpm",bpm).putInt("level",level).putBoolean("high",high).apply();
    }
    private Button button(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(18); b.setAllCaps(false); b.setFocusable(true); b.setMinHeight(64); return b;
    }
    private LinearLayout page(String h){
        LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(32,24,32,24); p.setBackgroundColor(Color.rgb(8,9,13));
        TextView t=new TextView(this); t.setText(h); t.setTextColor(Color.WHITE); t.setTextSize(30); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER_VERTICAL); p.addView(t,new LinearLayout.LayoutParams(-1,70)); return p;
    }
    private void set(LinearLayout p){ root=p; setContentView(p); p.setFocusable(true); p.requestFocus(); }

    private void showHome(){
        LinearLayout p=page("PE CONTROL TV");
        TextView t=new TextView(this); t.setText("Online training and video control"); t.setTextColor(Color.LTGRAY); t.setTextSize(16); p.addView(t,new LinearLayout.LayoutParams(-1,55));
        Button v=button("▶  VIDEOS"); v.setOnClickListener(x->showVideos()); p.addView(v);
        Button c=button("●  PE CONTROL"); c.setOnClickListener(x->showTraining()); p.addView(c);
        Button a=button("⚙  ADMIN"); a.setOnClickListener(x->showAdmin()); p.addView(a);
        set(p); v.requestFocus();
    }

    private void showVideos(){
        LinearLayout p=page("VIDEOS");
        String src=getSharedPreferences(PREFS,0).getString("source","");
        String cat=getSharedPreferences(PREFS,0).getString("category","");
        TextView info=new TextView(this); info.setText(src.isEmpty()?"No video source configured. Use ADMIN to add one.":"Source: "+src+"\nCategory: "+(cat.isEmpty()?"All":cat)); info.setTextColor(Color.LTGRAY); info.setTextSize(16); info.setPadding(0,0,0,12); p.addView(info,new LinearLayout.LayoutParams(-1,80));
        if(!src.isEmpty()){ Button play=button("▶  OPEN VIDEO SOURCE"); play.setOnClickListener(x->openWeb(src)); p.addView(play); }
        Button admin=button("＋  ADD / CHANGE SOURCE"); admin.setOnClickListener(x->editSource(true)); p.addView(admin);
        Button home=button("←  HOME"); home.setOnClickListener(x->showHome()); p.addView(home);
        set(p); (src.isEmpty()?admin:(Button)p.getChildAt(2)).requestFocus();
    }

    private void editSource(boolean fromVideos){
        LinearLayout p=page("VIDEO SOURCE");
        EditText url=new EditText(this); url.setSingleLine(true); url.setText(getSharedPreferences(PREFS,0).getString("source","")); url.setHint("https://example.com"); url.setTextColor(Color.WHITE); url.setHintTextColor(Color.GRAY); p.addView(url,new LinearLayout.LayoutParams(-1,70));
        EditText cat=new EditText(this); cat.setSingleLine(true); cat.setText(getSharedPreferences(PREFS,0).getString("category","")); cat.setHint("Category / search phrase"); cat.setTextColor(Color.WHITE); cat.setHintTextColor(Color.GRAY); p.addView(cat,new LinearLayout.LayoutParams(-1,70));
        Button save=button("SAVE"); save.setOnClickListener(x->{getSharedPreferences(PREFS,0).edit().putString("source",url.getText().toString().trim()).putString("category",cat.getText().toString().trim()).apply(); if(fromVideos)showVideos();else showAdmin();}); p.addView(save);
        Button test=button("TEST / OPEN"); test.setOnClickListener(x->openWeb(url.getText().toString().trim())); p.addView(test);
        Button back=button("←  BACK"); back.setOnClickListener(x->{if(fromVideos)showVideos();else showAdmin();}); p.addView(back);
        set(p); url.requestFocus();
    }

    private void showAdmin(){
        LinearLayout p=page("ADMIN");
        TextView t=new TextView(this); t.setText("Video sources are stored locally on this Fire Stick. Change them without rebuilding the APK."); t.setTextColor(Color.LTGRAY); t.setTextSize(16); p.addView(t,new LinearLayout.LayoutParams(-1,85));
        Button s=button("VIDEO SOURCES"); s.setOnClickListener(x->editSource(false)); p.addView(s);
        Button clear=button("CLEAR VIDEO SOURCE"); clear.setOnClickListener(x->{getSharedPreferences(PREFS,0).edit().remove("source").remove("category").apply();showAdmin();}); p.addView(clear);
        Button tr=button("PE CONTROL"); tr.setOnClickListener(x->showTraining()); p.addView(tr);
        Button home=button("←  HOME"); home.setOnClickListener(x->showHome()); p.addView(home);
        set(p); s.requestFocus();
    }

    private void showTraining(){
        LinearLayout p=page("PE CONTROL");
        TextView state=new TextView(this); state.setText("LEVEL "+level+"    BPM "+bpm+"    SESSION "+time()); state.setTextColor(Color.WHITE); state.setTextSize(20); p.addView(state,new LinearLayout.LayoutParams(-1,65));
        Button start=button(running?"Ⅱ  PAUSE":"▶  START"); start.setOnClickListener(x->{running=!running;if(running)tick();showTraining();});p.addView(start);
        Button lm=button("LEVEL −");lm.setOnClickListener(x->{level=Math.max(1,level-1);bpm=Math.min(220,60+level*10+(high?20:0));save();showTraining();});p.addView(lm);
        Button lp=button("LEVEL +");lp.setOnClickListener(x->{level=Math.min(10,level+1);bpm=Math.min(220,60+level*10+(high?20:0));save();showTraining();});p.addView(lp);
        Button bm=button("BPM −5");bm.setOnClickListener(x->{bpm=Math.max(30,bpm-5);save();showTraining();});p.addView(bm);
        Button bp=button("BPM +5");bp.setOnClickListener(x->{bpm=Math.min(220,bpm+5);save();showTraining();});p.addView(bp);
        Button hi=button(high?"HIGH INTENSITY: ON":"HIGH INTENSITY: OFF");hi.setOnClickListener(x->{high=!high;save();showTraining();});p.addView(hi);
        Button vids=button("▶  VIDEOS");vids.setOnClickListener(x->showVideos());p.addView(vids);
        Button home=button("←  HOME");home.setOnClickListener(x->showHome());p.addView(home);
        set(p);start.requestFocus();
    }

    private void openWeb(String url){
        if(url==null||url.trim().isEmpty()){editSource(true);return;}
        web=new WebView(this);
        WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setLoadWithOverviewMode(true);s.setUseWideViewPort(true);s.setBuiltInZoomControls(false);s.setSupportZoom(false);
        web.setBackgroundColor(Color.BLACK);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());web.setFocusable(true);web.requestFocus();web.loadUrl(url.trim());setContentView(web);
    }

    private void tick(){if(!running)return;seconds++;handler.postDelayed(this::tick,1000);}
    private String time(){return String.format(Locale.UK,"%02d:%02d",seconds/60,seconds%60);}

    @Override public void onBackPressed(){
        if(web!=null){if(web.canGoBack()){web.goBack();return;}web.destroy();web=null;showVideos();return;}
        showHome();
    }
    @Override protected void onStop(){
        super.onStop();
        // Fire TV WebView video resources can persist; stop the embedded page when leaving.
        if(web!=null){web.onPause();web.stopLoading();}
    }
    @Override protected void onDestroy(){running=false;handler.removeCallbacksAndMessages(null);if(web!=null)web.destroy();super.onDestroy();}
}
